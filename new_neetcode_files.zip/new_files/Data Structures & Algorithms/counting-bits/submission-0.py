class Solution:
    def countBits(self, n: int) -> List[int]:
        lis = []
        for i in range(n+1):
            count = 0
            for j in range(32):
                if i & (1<<j):
                    count+=1
            lis.append(count)
        return lis                 