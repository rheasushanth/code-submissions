class Solution:
    def isValid(self, s: str) -> bool:
        stack = []
        for i in range(len(s)):
            if s[i] in ['{', '[','(']:
                stack.append(s[i])
            elif s[i] == '}':
                if not stack or stack.pop() != '{':
                    return False
            elif s[i] == ']':
                if not stack or stack.pop() != '[':
                    return False
            elif s[i] == ')':
                if not stack or stack.pop() != '(':
                    return False
        return len(stack)==0
            
            
